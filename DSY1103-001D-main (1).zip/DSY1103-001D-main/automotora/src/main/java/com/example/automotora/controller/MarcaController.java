package com.example.automotora.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.automotora.models.entities.Marca;
import com.example.automotora.models.request.ActualizarMarca;
import com.example.automotora.models.request.AgregarMarca;
import com.example.automotora.services.MarcaService;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;




@RequestMapping("marca")
@RestController
public class MarcaController {
    
    @Autowired
    private MarcaService marcaService;

    @GetMapping("")
    public List<Marca> obtenerTodo() {
        return marcaService.obtenerTodasLasMarcas();
    }

    @GetMapping("/{idMarca}")
    public Marca obtenerPorId(@PathVariable int idMarca) {
        return marcaService.obtenerMarcaPorId(idMarca); 
    }

    @PostMapping("")
    public Marca agregarMarca(@RequestBody AgregarMarca nueva) {            
        return marcaService.agregarMarca(nueva);
    }
    

    @PutMapping("")
    public Marca actualizarMarca(@RequestBody ActualizarMarca nueva ) {
        return marcaService.actualizarMarca(nueva);
    }

    @DeleteMapping("/{idMarca}")
    public String eliminarMarca(@PathVariable int idMarca){
        return marcaService.eliminarMarca(idMarca);
    }
    

    


}
