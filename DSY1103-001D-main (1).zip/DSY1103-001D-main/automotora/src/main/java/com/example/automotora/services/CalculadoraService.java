package com.example.automotora.services;

import org.springframework.stereotype.Service;

@Service
public class CalculadoraService {
    
    public int sumar(int n1, int n2){
        return n1 + n2;
    }
    
}
