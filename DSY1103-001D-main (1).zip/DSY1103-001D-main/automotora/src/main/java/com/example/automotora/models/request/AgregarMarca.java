package com.example.automotora.models.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class AgregarMarca {
    @NotBlank
    private String nombre_marca;    
}
