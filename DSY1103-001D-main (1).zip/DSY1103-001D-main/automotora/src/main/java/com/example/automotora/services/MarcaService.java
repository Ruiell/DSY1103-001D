package com.example.automotora.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.example.automotora.models.entities.Marca;
import com.example.automotora.models.request.ActualizarMarca;
import com.example.automotora.models.request.AgregarMarca;
import com.example.automotora.repositories.MarcaRepository;

@Service
public class MarcaService {
    @Autowired
    private MarcaRepository marcaRepository;

    public List<Marca> obtenerTodasLasMarcas(){
        return marcaRepository.findAll();
    }


    public Marca obtenerMarcaPorId(int marcaId){
        Marca marca = marcaRepository.findById(marcaId).orElse(null);
        if (marca == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Marca no encontrada.");
        }
        return marca;
    }

    public Marca agregarMarca(AgregarMarca nuevo){
        Marca marca = new Marca();
        marca.setNombre_marca(nuevo.getNombre_marca());
        return marcaRepository.save(marca);
    }

    public Marca actualizarMarca(ActualizarMarca nuevo){
        Marca marca = marcaRepository.findById(nuevo.getId_marca()).orElse(null);
        if (marca == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Marca no encontrada.");
        }else{
            marca.setNombre_marca(nuevo.getNombre_marca());
            return marcaRepository.save(marca);
        }
    }


    public String eliminarMarca(int marcaId){
        if (marcaRepository.existsById(marcaId)) {
            marcaRepository.deleteById(marcaId);
            return "Marca eliminda correctamente.";
        }else{
             throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Marca no encontrada.");
        }
    }



}
