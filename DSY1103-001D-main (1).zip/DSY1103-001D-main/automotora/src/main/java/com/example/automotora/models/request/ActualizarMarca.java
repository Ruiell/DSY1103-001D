package com.example.automotora.models.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ActualizarMarca {    
    @NotBlank
    private int id_marca;
    @NotBlank
    private String nombre_marca;
}
