package com.example.gestionVehiculos.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.gestionVehiculos.models.entities.Vehiculo;
import com.example.gestionVehiculos.models.request.VehiculoAgregar;
import com.example.gestionVehiculos.services.VehiculoService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RequestMapping("vehiculo")
@RestController
public class VehiculoController {

    @Autowired
    private VehiculoService vehiculoService;

    @PostMapping("")
    public Vehiculo agregarVehiculo(@RequestBody VehiculoAgregar nuevo) {
        return vehiculoService.agregarVehiculo(nuevo);
    }
    
    
}
