package com.example.gestionVehiculos.models.dto;

public record MarcaDto (int id_marca, String nombre_marca){}
