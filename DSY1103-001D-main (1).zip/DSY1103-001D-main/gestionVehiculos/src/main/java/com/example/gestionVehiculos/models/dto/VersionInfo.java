package com.example.gestionVehiculos.models.dto;

public record VersionInfo(String nombreApp, String version) {}
