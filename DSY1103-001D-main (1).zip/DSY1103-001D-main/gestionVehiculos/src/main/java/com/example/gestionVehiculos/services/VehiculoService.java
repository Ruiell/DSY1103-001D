package com.example.gestionVehiculos.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;

import com.example.gestionVehiculos.models.dto.MarcaDto;
import com.example.gestionVehiculos.models.entities.Vehiculo;
import com.example.gestionVehiculos.models.request.VehiculoAgregar;
import com.example.gestionVehiculos.repositories.VehiculoRepository;

@Service
public class VehiculoService {
    
    @Autowired
    private VehiculoRepository vehiculoRepository;

    @Autowired
    private WebClient marcaWebClient;

    public Vehiculo agregarVehiculo(VehiculoAgregar nuevo){
        MarcaDto marca = null;
        try {
            marca = marcaWebClient.get()
            .uri("/marca/{id}",nuevo.getId_marca())
            .retrieve()
            .bodyToMono(MarcaDto.class)
            .block();
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Fallo el webCLient: " + e.getMessage() );
        }

        if (marca == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Marca no encontrada.");
        }

        Vehiculo v = new Vehiculo();
        v.setId_marca(nuevo.getId_marca());
        v.setModelo(nuevo.getModelo());
        v.setPatente(nuevo.getPatente());
        return vehiculoRepository.save(v);
    }
}
